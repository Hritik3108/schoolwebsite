package com.numetry.entity;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum Role{
	USER,
	ADMIN
}
