package com.numetry.entity;

public enum TokenType {
	BEARER
}
