import './index.scss'

const AcademySearchBox = () => {
    return (
        <div className="academySearchBox-Container">
            <h2>AcademySearchBox Here</h2>
        </div>
    )
}

export default AcademySearchBox;