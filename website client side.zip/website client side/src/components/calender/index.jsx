import './index.scss'
import { CalendarComponent } from '@syncfusion/ej2-react-calendars';

const Calender = () => {
    return (
        <>
            <CalendarComponent />
        </>
    )
}

export default Calender;