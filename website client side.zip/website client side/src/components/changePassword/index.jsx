import './index.scss'

const ChangePassword = () => {
    return (
        <>
        <h2>Welcome to ChangePassword page</h2>

        {/* todo 1.make a form same as login page requirements are email, old Password, new Password styling will be same as login page */}
        {/* todo 2.add the functions and react hooks same as login page */}
        {/* todo 3.functions to add handleChange handleSubmit async function change password */}
        {/* If needed change the stylesheet format to css from scss by changing the extension to .css*/}
        </>
    );
}

export default ChangePassword;