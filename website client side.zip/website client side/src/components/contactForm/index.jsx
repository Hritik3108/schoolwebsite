import './index.scss'

const ContactForm = () => {
    return (
        <div className="contactForm-container">
            <h2>Contact Form Here</h2>
        </div>
    )
}

export default ContactForm;