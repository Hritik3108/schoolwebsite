import './index.scss'

const HeadLine = () => {
    return (
        <div className="HeadLine-Container">
            <h2>HeadLines Here</h2>
        </div>
    )
}

export default HeadLine;