import './index.scss'

const WardList = () => {
    return (
        <div className="wardList-Container">
            <h2>Ward List Here</h2>
        </div>
    )
}

export default WardList;